package com.example.android.miwok;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {

    private Context mConext;

    FragmentAdapter(Context mContext ,FragmentManager fragmentManager) {
        super(fragmentManager);
        this.mConext = mContext;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: return new NumbersFragment();
            case 1: return new FamilyFragment();
            case 2: return new ColorsFragment();
            default: return new PhrasesFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0: return mConext.getString(R.string.category_numbers);
            case 1: return mConext.getString(R.string.category_family);
            case 2: return mConext.getString(R.string.category_colors);
            default: return mConext.getString(R.string.category_phrases);
        }
    }
}
