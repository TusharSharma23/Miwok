package com.example.android.miwok;

class words {

    /** Default translation for the word*/
    private String mDefault;

    /** Miwok Translation for the word*/
    private String mMiwok;

    /** Store image resource id*/
    private int mResourceId;


    private int mAudio;

    private boolean hasImage;
    /** Create a new word object
     * @param mDefault is the default language user understands
     *
     * @param mMiwok is its Miwok translation
     */
    public words(String mDefault, String mMiwok, int mAudio) {
        this.mDefault = mDefault;
        this.mMiwok = mMiwok;
        this.hasImage = false;
        this.mAudio = mAudio;
    }

    public words(String mDefault, String mMiwok,int mResourceId, int mAudio) {
        this.mDefault = mDefault;
        this.mMiwok = mMiwok;
        this.mResourceId = mResourceId;
        hasImage = true;
        this.mAudio = mAudio;
    }

    /** Get default translation for the word. */
    public String getDefault() {
        return mDefault;
    }

    /** Get Miwok translation*/
    public String getMiwok() {
        return mMiwok;
    }

    /** Get image to display*/
    public int getmResourceId() {
        return mResourceId;
    }


    public boolean hasImage() {
        return hasImage;
    }

    public int getAudio() {
        return mAudio;
    }
}
